
# PauseForSight

PauseForSight is an application designed to encourage users to take breaks and care for their eyes during prolonged computer use.

## Prerequisites

- Python 3.9

## Installation


1. Install the required dependencies:

   ```bash
   pip install -r requirements.txt
   ```

## Usage

To run the application, execute the following command:

```bash
python pauseForSight.py
```

The application will start, and you will receive prompts and notifications to take breaks for eye care during computer usage.




