import tkinter as tk

from eyes_tracker_app import EyeTrackerAPP

root = tk.Tk()
gui = EyeTrackerAPP(root)
root.mainloop()
